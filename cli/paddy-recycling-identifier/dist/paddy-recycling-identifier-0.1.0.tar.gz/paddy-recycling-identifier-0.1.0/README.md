# Recycling identifier

Simple cli tool for telling you what you can recycle.
