# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['paddy_recycling_identifier']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['recycle = paddy_recycling_identifier.main']}

setup_kwargs = {
    'name': 'paddy-recycling-identifier',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Recycling identifier\n\nSimple cli tool for telling you what you can recycle.\n',
    'author': 'Paddy Cooper',
    'author_email': '1210@rgsg.co.uk',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
